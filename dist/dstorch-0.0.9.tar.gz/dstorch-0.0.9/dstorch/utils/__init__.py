from .initialization import random_weight_init
from .analysis import calc_jacobian