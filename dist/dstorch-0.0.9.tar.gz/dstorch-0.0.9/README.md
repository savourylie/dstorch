# dstorch
dstorch is a Python module for deep learning built on top of PyTorch.

# Installation
## Dependencies
dstorch requires:

* Python (>= 3.5)
* Numpy (>= 1.11.0)
* PyTorch (>= 0.4.0)

## User installation
```
git clone https://github.com/savourylie/dstorch.git
cd dstorch
pip install .
```